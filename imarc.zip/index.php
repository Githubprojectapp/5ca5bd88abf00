
<!doctype html>
<!--[if lt IE 7]>		<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>			<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>			<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->	<html class="no-js" lang=""> <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>IMARC-2019 : International Conference at CT University, Ludhiana, Punjab, India </title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="apple-touch-icon" href="apple-touch-icon.png">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/customScrollbar.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/owl.carousel.css">
	<link rel="stylesheet" href="css/prettyPhoto.css">
	<link rel="stylesheet" href="css/jquery.fullpage.css">
	<link rel="stylesheet" href="css/transitions.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/color.css">
	<link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/table.css">
	<script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
	<style>
		html,
		body{height: auto;}
		
		/* DivTable.com */
.divTable{
	display: table;
	width: 100%;
}
.divTableRow {
	display: table-row;
}
.divTableHeading {
	background-color: #EEE;
	display: table-header-group;
}
.divTableCell, .divTableHead {
	border: 1px solid #999999;
	display: table-cell;
	padding: 3px 10px;
}
.divTableHeading {
	background-color: #EEE;
	display: table-header-group;
	font-weight: bold;
}
.divTableFoot {
	background-color: #EEE;
	display: table-footer-group;
	font-weight: bold;
}
.divTableBody {
	display: table-row-group;
}
	</style>
</head>
<body class="tg-home tg-homeone">
	<!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
	<!--************************************
			Cookie Popup Start
	*************************************-->
	<!--<div class="tg-alert alert alert-success">
			<i class="icon-star"></i>
		<span class="tg-alertcontent"><strong>Info Message:</strong> By continuing to use the site, you agree to the use of cookies. more information 
			<a class="tg-btn" href="#">Accept</a>
			<a href="#" class="close" data-dismiss="alert">�</a>
		</span>
	</div>-->
	<!--************************************
			Cookie Popup End
	*************************************-->
	<!--************************************
			Wrapper Start
	*************************************-->
	<div id="tg-wrapper" class="tg-wrapper tg-haslayout">

		<!--************************************
				Header Start
		*************************************-->
		<header id="tg-header" class="tg-header tg-haslayout">
			<div class="container">
				<div class="row">
					
                      <?php include ("header.php"); ?>
				</div>
			</div>
		</header>
		<!--************************************
				Header End
		*************************************-->
		<!--************************************
				Home Slider Start
		*************************************-->
	<div class="tg-bannerholder">
			<ul class="tg-socialicons tg-bannersocialicons">
				<li><a href="https://www.facebook.com/CTUniversityludhiana/"><i class="fa fa-facebook"></i></a></li>
				<li><a href="https://twitter.com/CT_University"><i class="fa fa-twitter"></i></a></li>
				<li><a href="https://www.youtube.com/channel/UCOD3pxKIGVtpKdqKXsYvi5Q"><i class="fa fa-youtube"></i></a></li>
				<li><a href="https://www.instagram.com/ctuniversityofficial/"><i class="fa fa-instagram"></i></a></li>
			</ul>
			<a class="tg-btnscroll tg-floating tg-btnsectionscroll" href="javascript:void(0);">
				<img src="images/btn-scroll.png" alt="image description">
				<span>Scroll For Details</span>
				<i class="fa fa-angle-double-down"></i>			</a>
			<div id="tg-homeslider" class="tg-homeslider tg-haslayout owl-carousel">
				<figure class="item tg-bannerimg" data-vide-bg="poster: images/slider/slide-01.jpg" data-vide-options="position: 0% 50%">
					<figcaption>
						<div class="container">
						    
							<div class="tg-slidercontent margin-top">
							    <div><img src="images/ct-logo-1.png" style="width:35%; margin:0 auto; margin-bottom: 18px;"></div>
							    <span>organizing</span>
								<h1>IMARC-2019</h1>
							<div class="tg-slidercontent-n">
							    <img src="images/calender.png" style="width:30px; margin:0 auto; display:inline-block;">
							    <span>06-07 September 2019</span>
							</div>	
									
									<div class="tg-slidercontent-n">
									<img src="images/location.png" style="width:23px; margin:0 auto; display:inline-block;">
									<span>CT University, Ludhiana</span>
									</div>
									
									<div class="tg-slidercontent-n">
									 <img src="images/location.png" style="width:23px; margin:0 auto; display:inline-block;">
									<span>CT Group of Institutions, Jalandhar</span>
									</div>
							
							
							</div>
						</div>
					</figcaption>
				</figure>
				<figure class="item tg-bannerimg" data-vide-bg="poster: images/slider/slide-02.jpg" data-vide-options="position: 0% 50%">
					<figcaption>
						<div class="container">
						    
                            <div class="tg-slidercontent margin-top">
							    <div><img src="images/ct-logo-1.png" style="width:35%; margin:0 auto; margin-bottom: 18px;"></div>
							    <span>organizing</span>
								<h1>IMARC-2019</h1>
							<div class="tg-slidercontent-n">
							    <img src="images/calender.png" style="width:30px; margin:0 auto; display:inline-block;">
							    <span>06-07 September 2019</span>
							</div>	
									
									<div class="tg-slidercontent-n">
									<img src="images/location.png" style="width:23px; margin:0 auto; display:inline-block;">
									<span>CT University, Ludhiana</span>
									</div>
									
									<div class="tg-slidercontent-n">
									 <img src="images/location.png" style="width:23px; margin:0 auto; display:inline-block;">
									<span>CT Group of Institutions, Jalandhar</span>
									</div>
							
							
							</div>
								
						</div>
					</figcaption>
				</figure>
				<figure class="item tg-bannerimg" data-vide-bg="poster: images/slider/slide-03.jpg" data-vide-options="position: 0% 50%">
					<figcaption>
						<div class="container">
						    
							<div class="tg-slidercontent margin-top">
							    <div><img src="images/ct-logo-1.png" style="width:35%; margin:0 auto; margin-bottom: 18px;"></div>
							    <span>organizing</span>
								<h1>IMARC-2019</h1>
							<div class="tg-slidercontent-n">
							    <img src="images/calender.png" style="width:30px; margin:0 auto; display:inline-block;">
							    <span>06-07 September 2019</span>
							</div>	
									
									<div class="tg-slidercontent-n">
									<img src="images/location.png" style="width:23px; margin:0 auto; display:inline-block;">
									<span>CT University, Ludhiana</span>
									</div>
									
									<div class="tg-slidercontent-n">
									 <img src="images/location.png" style="width:23px; margin:0 auto; display:inline-block;">
									<span>CT Group of Institutions, Jalandhar</span>
									</div>
							
							
							</div>
						
						</div>
					</figcaption>
				</figure>
			</div>
		</div>
		<!--************************************
				Home Slider End
		*************************************-->
		<!--************************************
				Main Start
		*************************************-->
		<main id="tg-main" class="tg-main tg-haslayout">
			<!--************************************
					About Us Start					
			*************************************-->
			<section id="tg-aboutus" class="tg-sectionspace tg-haslayout">
				<div class="container">
					<div class="row"><a name="imarc"></a>
						<div class="tg-shortcode tg-aboutusshortcode">
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pull-left">
								<div class="tg-shortcodetext">
									<div class="tg-sectionhead tg-textalignleft">
										<div class="tg-sectionheading">
											<h2>About The Conference</h2>
											<h3 style="color:#224484">IMARC 2019</h3>
										</div>
										<div class="tg-description">
											<p align="justify" style="font-size:14px"><b>CT University,</b> Ludhiana (Punjab, India) in association with CT Group of Institutes, Shahpur Campus,  and Maqsudan Campus, Jalandhar (Punjab, India) is organizing an <b>“International Multi-disciplinary Academic Research Conference (IMARC-2019)”</b> on 6-7 September 2019 at CT University Campus, Ludhiana/Jalandhar (Punjab, India). The IMARC-2019 will be the ideal platform for the delegates to develop a close interaction among scientists, students and planners engaged in research and academics in multidisciplinary facets of science, technology and humanities and will offer a track of quality R&D updates from eminent experts. </p>
										</div>
									</div>
									<div class="tg-btnarea">
										<!--<a class="tg-btn" href="#">More about IMARC</a>-->
										<a class="tg-btn" href="schedule.php">View Schedule</a>									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pull-right">
								<figure class="tg-shortcodeimg tg-shadow">
									<img src="images/img-01.jpg" alt="image description">								</figure>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--************************************
					About Us End					
			*************************************-->
			<!--************************************
					Statistics Start				
			*************************************-->
			<section class="tg-haslayout tg-bgparallax tg-bgcounter">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<div id="tg-statisticscounters" class="tg-statisticscounters">
								<div class="tg-counterholder">
									<div class="tg-counter">
										<h2><span data-from="0" data-to="140" data-speed="2000" data-refresh-interval="50">140</span></h2>
										<h3>Speakers</h3>
										<span class="tg-statisticicon icon-user"></span>									</div>
								</div>
								<div class="tg-counterholder">
									<div class="tg-counter">
										<h2><span data-from="0" data-to="02" data-speed="2000" data-refresh-interval="50">02</span></h2>
										<h3>Days Event</h3>
										<span class="tg-statisticicon icon-calendar-full"></span>									</div>
								</div>
								<div class="tg-counterholder">
									<div class="tg-counter">
										<h2><span data-from="0" data-to="50" data-speed="2000" data-refresh-interval="50">50</span></h2>
										<h3>Panel Discussions</h3>
										<span class="tg-statisticicon icon-briefcase"></span>									</div>
								</div>
								<div class="tg-counterholder">
									<div class="tg-counter">
										<h2><span data-from="0" data-to="7" data-speed="2000" data-refresh-interval="50">7</span></h2>
										<h3>Themes</h3>
										<span class="tg-statisticicon icon-enter"></span>									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--************************************
					Statistics End				
			*************************************-->
            
                        <!--************************************
					About Us Start					
			*************************************-->
			<section id="tg-aboutus" class="tg-sectionspace tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="tg-shortcode tg-aboutusshortcode">
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pull-right">
								<figure class="tg-shortcodeimg tg-shadow">
									<img src="images/img-04.jpg" alt="image description">								</figure>
							</div>
                            
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pull-left">
								<div class="tg-shortcodetext">
									<div class="tg-sectionhead tg-textalignleft">
										<div class="tg-sectionheading">
											<!--<h2>About The Conference</h2>-->
											<h3 style="color:#224484">IMARC 2019 : Highlights</h3>
										</div>
										<div class="tg-description">
											<!--<p align="justify">CT University, Ludhiana (Punjab, India) in association with CT Group of Institutes, Shahpur Campus,  and Maqsudan Campus, Jalandhar (Punjab, India) is organizing an “International Multi-disciplinary Academic Research Conference (IMARC-2019)” on 6-7 September 2019 at CT University Campus, Ludhiana/Jalandhar (Punjab, India). The IMARC-2019 will be the ideal platform for the delegates to develop a close interaction among scientists, students and planners engaged in research and academics in multidisciplinary facets of science, technology and humanities and will offer a track of quality R&D updates from eminent experts. </p>-->
                                            <ul class="tg-liststyle" style="font-size:14px">
											<li><b>Pre-Conference Workshops</b> by Internationally renowned speakers and in partnership with leading corporate houses on emerging technologies/research areas</li>
											<li><b>Keynote sessions </b>from eminent personalities</li>
											<li><b>50+ Panel Discussions</b> in Plenary and Concurrent sessions</li>
											<li>Research Papers Presentations and Case Study Competition</li>
											
											<li>Under the <b>“Innovate or Evaporate” activity,</b> innovation design projects competition / innovative ideas poster presentation competition by students will be held</li>                                            
                                            <li><b>Virtual Business Plan Competition</b></li>
                                             <li><b>“Wealth from the Waste”</b> – An exposition of Zero-Waste CT University</li>
 <li><b>Thematic Start-up Exhibition</b> by young entrepreneurs and CT University Alumni</li>
 <li>Excellence Awards in Technology, innovation, Entrepreneurship and Leadership </li>
<li> Interaction with Corporate Sector tycoons</li>
<li>Mentoring sessions by Experts for start-up venture/winners of Competitions</li>
										</ul>
										</div>
									</div>
									<!--<div class="tg-btnarea">
										<a class="tg-btn" href="#">More about IMARC</a>
										<a class="tg-btn" href="#">View Schedule</a>
									</div>-->
								</div>
							</div>
                        </div>                        
					</div>
				</div>
			</section>
			<!--************************************
					About Us End					
			*************************************-->
            
            
            			<!--************************************
					Testimonial Signup Start		
			*************************************-->
			<section class="tg-haslayout tg-bgparallax tg-bgtestimonial">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<div class="tg-testimonials tg-colorwhite">
								<div class="tg-sectionhead tg-textalignleft">
									<div class="tg-sectionheading">
										<!--<h2>People Love Our Events</h2>-->
										<h3>What They Say About Us</h3>
									</div>
								</div>
								
                                <div id="tg-testimonialslider" class="tg-testimonialslider owl-carousel">
									
                                    
                                    <div class="item tg-testimonial">
										<i class="fa fa-quote-left"></i>
										<figure class="tg-clientimg tg-themeimgborder">
											<img src="images/testimonials/img-01.jpg" alt="image description">										</figure>
										<div class="tg-testimonialcontent">
											<div class="tg-clientname">
												<!--<span>Tee Hallmark</span>-->
												<h3>Prof. Dr. David Asirvatham, Malaysia</h3>
											</div>
											<div class="tg-description">
												<p>
                                                "IMARC 2019 is a great initiative from CT University, Ludhiana. It's a Multidisciplinary Conference, a big platform for all the researchers from different domains to provide their innovative ideas. I wish all the best to CT University for this wonderful event and conference."</p>
											</div>
										</div>
									</div>
                                    
                                    
									<!--<div class="item tg-testimonial">
										<i class="fa fa-quote-left"></i>
										<figure class="tg-clientimg tg-themeimgborder">
											<img src="images/testimonials/img-02.jpg" alt="image description">										</figure>
										<div class="tg-testimonialcontent">
											<div class="tg-clientname">
												<span>Speaker</span>
												<h2>Name</h2>
											</div>
											<div class="tg-description">
												<p>"Conectetur adipiscing elit sediio eiusmod tempor incididunt utnai labore aloreaie magna aliqua enm adea minim."</p>
											</div>
										</div>
									</div>-->
								
                                	<!--<div class="item tg-testimonial">
										<i class="fa fa-quote-left"></i>
										<figure class="tg-clientimg tg-themeimgborder">
											<img src="images/testimonials/img-01.jpg" alt="image description">										</figure>
										<div class="tg-testimonialcontent">
											<div class="tg-clientname">
												<span>Designer @ Tee Hallmark</span>
												<h2>Name</h2>
											</div>
											<div class="tg-description">
												<p>"Conectetur adipiscing elit sediio eiusmod tempor incididunt utnai labore aloreaie magna aliqua enm adea minim."</p>
											</div>
										</div>
									</div>-->
                                    
                                    
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5 pull-right"><a name="deadlines"></a>
							<div class="tg-signup"><a name="deadlines"></a>
								<figure class="tg-signupimg">
									<img src="images/img-02.jpg" alt="image description">
									<figcaption>
										<div class="tg-signupcontent">
											<!--<h2>Don�t Worry, It�s Scam Free</h2>-->
											<h3>Important Deadlines!</h3>
										</div>
									</figcaption>
								</figure>
								<ul>
                                <li style="font-size:14px"><b>Abstract Submission Deadline : </b>July  15, 2019</li>
                                 <li style="font-size:14px"><b>Notification of Acceptances/ Rejection :</b> Within 7 days </li>
                                 <li style="font-size:14px"><b>Early bird registration : </b>July 15, 2019</li>
                                 <li style="font-size:14px"><b>Pre-conference Workshops :</b> September 5, 2019</li>
                                 <li style="font-size:14px"><b>Conference Date :</b> September 6-7, 2019</li>
                                 <li style="font-size:14px"><b>Gala Dinner :</b> September 6, 2019,   7:30 PM</li>
                                 <li style="font-size:14px"><b>Last date to submit the full paper :</b> August 15, 2019</li>
                                </ul>
							</div>
						</div>
					</div><br><br>
				</div>
			</section>
			<!--************************************
					Testimonial Signup End			
			*************************************-->
            
            
            
			<!--************************************
					Speakers Start				
			*************************************-->
			<section class="tg-sectionspace tg-haslayout">
				<div class="container"><a name="speakers"></a>
					<div class="row">
						<div class="tg-shortcode tg-speakershortcode">
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<div class="tg-shortcodetext">
									<div class="tg-sectionhead tg-textalignleft">
										<div class="tg-sectionheading">
<!--											<h2>Professionals From Around The World</h2>-->
											<h3 style="color:#224484">Internationally Renowned Speakers &amp; Eminent Personalities</h3>
										</div>
										<div class="tg-description">
											<p align="justify">Galaxy of renowned Entrepreneurs, Academicians, Researchers, Govt. Officials, Venture Capitalists, SMEs, CEO of Incubators / Accelerators, Banking and Financing Experts, Agricultural Entrepreneurs, Farm Scientists and Policy Planners, Industry Professionals, Corporate Leaders and Students shall be participating in IMARC-2019.</p>
										</div>
									</div>
									<div class="tg-btnarea">
										<a class="tg-btn" href="#">View All Speakers</a>									</div>
								</div>
							</div>
                            
                            
							<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/speakers/dr-marisha.jpg" alt="image description">
										<figcaption>
											<!--<ul class="tg-socialicons">
												<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
												<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
												<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
												<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
												<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
											</ul>-->
										</figcaption>
									</figure>
									<div class="tg-posttitle">
										<h5><a href="">Dr. Marisha Berenice McAuliffe</a></h5>
										<span style="font-size:15px; line-height:18px">Academic Director, <br>Barclays College,<br> Melbourne, Australia</span>									</div>
								</div>
							</div>
                            
                                         
							<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/speakers/dr-david.jpg" alt="image description">
										<figcaption>
											<!--<ul class="tg-socialicons">
												<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
												<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
												<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
												<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
												<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
											</ul>-->
										</figcaption>
									</figure>
									<div class="tg-posttitle">
										<h5><a href="">Prof. Dr. David Asirvatham</a></h5>
										<span style="font-size:15px; line-height:18px">Executive Dean, Faculty of Built Environment, Engineering, Technology and Design,<br>Taylor's University, Malaysia</span>									</div>
								</div>
							</div>
                            
                            
							<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/speakers/dr-cristi-spulbar.jpg" alt="image description">
										<figcaption>
											<!--<ul class="tg-socialicons">
												<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
												<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
												<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
												<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
												<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
											</ul>-->
										</figcaption>
									</figure>
									<div class="tg-posttitle">
										<h5><a href="">Dr. Cristi Spulbar </a></h5>
										<span style="font-size:15px; line-height:18px">Professor, Habilitated Doctor at University of Craiova, Faculty of Economics and Business Administration, Dolj County, Romania </span>									</div>
								</div>
							</div>
                            
							<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/speakers/dr-wolfgang-amann.jpg" alt="image description">
										<figcaption>
											<!--<ul class="tg-socialicons">
												<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
												<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
												<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
												<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
												<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
											</ul>-->
										</figcaption>
									</figure>
									<div class="tg-posttitle">
										<h5><a href="">Prof. Dr. Wolfgang Amann  </a></h5>
										<span style="font-size:15px; line-height:18px">HEC Paris, Qatar </span>									</div>
								</div>
							</div>
							<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/speakers/gideon-adeniyi.jpg" alt="image description">
										<figcaption>
											<!--<ul class="tg-socialicons">
												<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
												<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
												<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
												<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
												<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
											</ul>-->
										</figcaption>
									</figure>
									<div class="tg-posttitle">
										<h5><a href="">Gideon Adeniyi   </a></h5>
										<span style="font-size:15px; line-height:18px">Global Goodwill Ambassador| Health Advocate| Ambassador, My Body Is My Body| Executive Director, NLN, Nigeria </span>									</div>
								</div>
							</div>
							<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/speakers/richard-bush.jpg" alt="image description">
										<figcaption>
											<!--<ul class="tg-socialicons">
												<li class="tg-facebook"><a href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
												<li class="tg-twitter"><a href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
												<li class="tg-linkedin"><a href="javascript:void(0);"><i class="fa fa-linkedin"></i></a></li>
												<li class="tg-googleplus"><a href="javascript:void(0);"><i class="fa fa-google-plus"></i></a></li>
												<li class="tg-rss"><a href="javascript:void(0);"><i class="fa fa-rss"></i></a></li>
											</ul>-->
										</figcaption>
									</figure>
									<div class="tg-posttitle">
										<h5><a href="">Richard Bush </a></h5>
										<span style="font-size:15px; line-height:18px">Dean, College of Information Technology, Baker College 
Greater Detroit Area </span>									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--************************************
					Speakers End				
			*************************************-->
            
            
            

            
            
            
            
            
            
			<!--************************************
					Feature Event Start				
			*************************************-->
			<section class="tg-haslayout tg-bgparallax tg-bgfeatureevent">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<div class="tg-featuredevent">
								<span class="tg-featuretag">Featured Event</span>
								<h2>“Wealth from the Waste”  <span style="font-size:26px">An exposition of Zero-Waste CT University</span></h2>
								<time datetime="2019-09-06">September 06, 2019</time>
								<a class="tg-btnaddtocalender" href="#"><i class="icon-calendar-full"></i>
                                <span>Read more</span></a>							</div>
						</div>
					</div><br><br>
				</div>
			</section>
			<!--************************************
					Feature Event End				
			*************************************-->
            
			<!--************************************
					Event Schedule Start			
			*************************************-->
            
<!--			<section class="tg-sectionspace tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-12 col-md-offset-2 col-md-8 col-lg-offset-2 col-lg-8">
							<div class="tg-sectionhead">
								<div class="tg-sectionheading">
									<h2>Don't Miss This Event</h2>
									<h3>Great Event Schedule</h3>
								</div>
								<div class="tg-description">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt utnaecte laboret dolore magna aliqua enim adiatai minim veniam quista nostrud exercitation ullamco laboris nisi ut aliquip exeation.</p>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<div class="tg-eventscheduletabs">
								<ul class="tg-eventschedulenav" role="tablist">
									<li role="presentation" class="active"><a href="#day-one" aria-controls="day-one" role="tab" data-toggle="tab">Day 01<span>June 27, 2017</span></a></li>
									<li role="presentation"><a href="#day-two" aria-controls="day-two" role="tab" data-toggle="tab">Day 02<span>June 28, 2017</span></a></li>
									<li role="presentation"><a href="#day-three" aria-controls="day-three" role="tab" data-toggle="tab">Day 03<span>June 29, 2017</span></a></li>
									<li role="presentation"><a href="#day-four" aria-controls="day-four" role="tab" data-toggle="tab">Day 04<span>June 30, 2017</span></a></li>
								</ul>
								<div class="tg-eventschedulecontent tab-content">
									<a class="tg-btndownloadschedule" href="#">Download Full Schedule<i class="fa fa-angle-right"></i></a>
									<div role="tabpanel" class="tab-pane active" id="day-one">
										<div class="tg-eventschaduletime">
											<h2>Day 01 full schedule</h2>
											<h3>June 27, 2017 @ 09 - 11 am</h3>
										</div>
										<div class="tg-eventvenuetabs">
											<ul class="tg-eventvenuenav" role="tablist">
												<li role="presentation" class="active"><a href="#hall-one" aria-controls="hall-one" role="tab" data-toggle="tab">Hall Title 01</a></li>
												<li role="presentation"><a href="#hall-two" aria-controls="hall-two" role="tab" data-toggle="tab">Hall Title 02</a></li>
												<li role="presentation"><a href="#hall-three" aria-controls="hall-three" role="tab" data-toggle="tab">Hall Title 03</a></li>
												<li role="presentation"><a href="#hall-four" aria-controls="hall-four" role="tab" data-toggle="tab">Hall Title 04</a></li>
												<li role="presentation"><a href="#hall-five" aria-controls="hall-four" role="tab" data-toggle="tab">Hall Title 05</a></li>
											</ul>
											<div class="tg-eventvenuecontent tab-content">
												<div role="tabpanel" class="tab-pane active" id="hall-one">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-two">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-10.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-11.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-12.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-three">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-four">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-10.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-11.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-12.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-five">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div role="tabpanel" class="tab-pane" id="day-two">
										<div class="tg-eventschaduletime">
											<h2>Day 02 full schedule</h2>
											<h3>June 28, 2017 @ 09 - 11 am</h3>
										</div>
										<div class="tg-eventvenuetabs">
											<ul class="tg-eventvenuenav" role="tablist">
												<li role="presentation" class="active"><a href="#hall-one" aria-controls="hall-one" role="tab" data-toggle="tab">Hall Title 01</a></li>
												<li role="presentation"><a href="#hall-two" aria-controls="hall-two" role="tab" data-toggle="tab">Hall Title 02</a></li>
												<li role="presentation"><a href="#hall-three" aria-controls="hall-three" role="tab" data-toggle="tab">Hall Title 03</a></li>
												<li role="presentation"><a href="#hall-four" aria-controls="hall-four" role="tab" data-toggle="tab">Hall Title 04</a></li>
												<li role="presentation"><a href="#hall-five" aria-controls="hall-four" role="tab" data-toggle="tab">Hall Title 05</a></li>
											</ul>
											<div class="tg-eventvenuecontent tab-content">
												<div role="tabpanel" class="tab-pane active" id="hall-six">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-seven">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-10.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-11.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-12.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-eight">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-nine">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-10.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-11.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-12.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-ten">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div role="tabpanel" class="tab-pane" id="day-three">
										<div class="tg-eventschaduletime">
											<h2>Day 03 full schedule</h2>
											<h3>June 28, 2017 @ 09 - 11 am</h3>
										</div>
										<div class="tg-eventvenuetabs">
											<ul class="tg-eventvenuenav" role="tablist">
												<li role="presentation" class="active"><a href="#hall-one" aria-controls="hall-one" role="tab" data-toggle="tab">Hall Title 01</a></li>
												<li role="presentation"><a href="#hall-two" aria-controls="hall-two" role="tab" data-toggle="tab">Hall Title 02</a></li>
												<li role="presentation"><a href="#hall-three" aria-controls="hall-three" role="tab" data-toggle="tab">Hall Title 03</a></li>
												<li role="presentation"><a href="#hall-four" aria-controls="hall-four" role="tab" data-toggle="tab">Hall Title 04</a></li>
												<li role="presentation"><a href="#hall-five" aria-controls="hall-four" role="tab" data-toggle="tab">Hall Title 05</a></li>
											</ul>
											<div class="tg-eventvenuecontent tab-content">
												<div role="tabpanel" class="tab-pane active" id="hall-eleven">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-twelve">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-thirteen">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-fourteen">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-fifteen">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div role="tabpanel" class="tab-pane" id="day-four">
										<div class="tg-eventschaduletime">
											<h2>Day 04 full schedule</h2>
											<h3>June 29, 2017 @ 09 - 11 am</h3>
										</div>
										<div class="tg-eventvenuetabs">
											<ul class="tg-eventvenuenav" role="tablist">
												<li role="presentation" class="active"><a href="#hall-one" aria-controls="hall-one" role="tab" data-toggle="tab">Hall Title 01</a></li>
												<li role="presentation"><a href="#hall-two" aria-controls="hall-two" role="tab" data-toggle="tab">Hall Title 02</a></li>
												<li role="presentation"><a href="#hall-three" aria-controls="hall-three" role="tab" data-toggle="tab">Hall Title 03</a></li>
												<li role="presentation"><a href="#hall-four" aria-controls="hall-four" role="tab" data-toggle="tab">Hall Title 04</a></li>
												<li role="presentation"><a href="#hall-five" aria-controls="hall-four" role="tab" data-toggle="tab">Hall Title 05</a></li>
											</ul>
											<div class="tg-eventvenuecontent tab-content">
												<div role="tabpanel" class="tab-pane active" id="hall-sixteen">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-seventeen">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-eighteen">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-ninteen">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="hall-twenty">
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-07.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Gathering &amp; welcome speech</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-08.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Getting Back into The Deliverables Business</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event tg-eventbreak">
														<div class="tg-eventhead">
															<div class="tg-leftarea">
																<time datetime="2017-12-12">10:30 am - 11:00 am</time>
																<div class="tg-title">
																	<h2>Lunch break</h2>
																</div>
															</div>
														</div>
													</div>
													<div class="tg-event">
														<div class="tg-eventspeaker">
															<figure class="tg-eventspeakerimg tg-themeimgborder">
																<img src="images/speakers/img-09.jpg" alt="image description">
															</figure>
															<div class="tg-contentbox">
																<div class="tg-eventhead">
																<div class="tg-leftarea">
																	<time datetime="2017-12-12">09:00 am - 09:30 am</time>
																	<div class="tg-title">
																		<h2>Successful Marketing Strategy</h2>
																	</div>
																</div>
																<div class="tg-rightarea">
																	<a class="tg-btnfarword" href="#"><i class="fa fa-mail-forward"></i></a>
																</div>
															</div>
																<div class="tg-description">
																<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt labore dolore magna aliqua enim ad minim veniam quis nostrud exion ullaoaris nisi ut aliquipa ex ea commodo consequat aute irure dolor.</p>
															</div>
																<div class="tg-speakername">
																	<h2>Robin meany</h2>
																	<span class="tg-eventcatagory">Senior manager</span>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>-->
			<!--************************************
					Event Schedule End				
			*************************************-->
            
			<!--************************************
					Testimonial Signup Start		
			*************************************-->
<!--			<section class="tg-haslayout tg-bgparallax tg-bgtestimonial">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<div class="tg-testimonials tg-colorwhite">
								<div class="tg-sectionhead tg-textalignleft">
									<div class="tg-sectionheading">
										<h2>People Love Our Events</h2>
										<h3>See What They Say About Our Events</h3>
									</div>
								</div>
								<div id="tg-testimonialslider" class="tg-testimonialslider owl-carousel">
									<div class="item tg-testimonial">
										<i class="fa fa-quote-left"></i>
										<figure class="tg-clientimg tg-themeimgborder">
											<img src="images/testimonials/img-01.jpg" alt="image description">
										</figure>
										<div class="tg-testimonialcontent">
											<div class="tg-clientname">
												<span>Tee Hallmark</span>
												<h2>Christy Warrick</h2>
											</div>
											<div class="tg-description">
												<p>� Conectetur adipiscing elit sediio eiusmod tempor incididunt utnai labore aloreaie magna aliqua enm adea minim.�</p>
											</div>
										</div>
									</div>
									<div class="item tg-testimonial">
										<i class="fa fa-quote-left"></i>
										<figure class="tg-clientimg tg-themeimgborder">
											<img src="images/testimonials/img-02.jpg" alt="image description">
										</figure>
										<div class="tg-testimonialcontent">
											<div class="tg-clientname">
												<span>Speaker</span>
												<h2>Christy Warrick</h2>
											</div>
											<div class="tg-description">
												<p>� Conectetur adipiscing elit sediio eiusmod tempor incididunt utnai labore aloreaie magna aliqua enm adea minim.�</p>
											</div>
										</div>
									</div>
									<div class="item tg-testimonial">
										<i class="fa fa-quote-left"></i>
										<figure class="tg-clientimg tg-themeimgborder">
											<img src="images/testimonials/img-03.jpg" alt="image description">
										</figure>
										<div class="tg-testimonialcontent">
											<div class="tg-clientname">
												<span>Designer @ Tee Hallmark</span>
												<h2>Christy Warrick</h2>
											</div>
											<div class="tg-description">
												<p>� Conectetur adipiscing elit sediio eiusmod tempor incididunt utnai labore aloreaie magna aliqua enm adea minim.�</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5 pull-right"><a name="deadlines"></a>
							<div class="tg-signup">
								<figure class="tg-signupimg">
									<img src="images/img-02.jpg" alt="image description">
									<figcaption>
										<div class="tg-signupcontent">
											
											<h3>Important Deadlines!</h3>
										</div>
									</figcaption>
								</figure>
								<ul>
                                <li style="font-size:14px"><b>Abstract Submission Deadline : </b>July  15, 2019</li>
                                 <li style="font-size:14px"><b>Notification of Acceptances/ Rejection :</b> Within 7 days </li>
                                 <li style="font-size:14px"><b>Early bird registration : </b>July 15, 2019</li>
                                 <li style="font-size:14px"><b>Pre-conference Workshops :</b> September 5, 2019</li>
                                 <li style="font-size:14px"><b>Conference Date :</b> September 6-7, 2019</li>
                                 <li style="font-size:14px"><b>Gala Dinner :</b> September 6, 2019,   7:30 PM</li>
                                 <li style="font-size:14px"><b>Last date to submit the full paper :</b> August 15, 2019</li>
                                
                                </ul>
							</div>
						</div>
					</div>
				</div>
			</section>-->
			<!--************************************
					Testimonial Signup End			
			*************************************-->
            
			<!--************************************
					Gallery Start					
			*************************************-->
<!--			<section class="tg-sectionspace tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-12 col-md-offset-2 col-md-8 col-lg-offset-2 col-lg-8">
							<div class="tg-sectionhead">
								<div class="tg-sectionheading">
									<h2>Clicks From Previous Events</h2>
									<h3>Our Events Gallery</h3>
								</div>
								<div class="tg-description">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt utnaecte laboret dolore magna aliqua enim adiatai minim veniam quista nostrud exercitation ullamco laboris nisi ut aliquip exeation.</p>
								</div>
							</div>
						</div>
						<div class="col-xs-12 col-sm-12 col-mg-12 col-lg-12">
							<div class="tg-gallerymasnory">
								<ul id="tg-navfilterbale" class="tg-navfilterbale tg-optionset">
									<li><a class="tg-active" data-filter="*" href="javascript:void(0);">Event In 2013</a></li>
									<li><a data-filter=".womenlaw" href="javascript:void(0);">Event In 2014</a></li>
									<li><a data-filter=".criminallaw" href="javascript:void(0);">Event In 2015</a></li>
									<li><a data-filter=".childlaw" href="javascript:void(0);">Event In 2016</a></li>
									<li><a data-filter=".vatinarylaw" href="javascript:void(0);">Event In 2017</a></li>
								</ul>
								<div id="tg-galleryfilterable" class="tg-galleryfilterable">
									<div class="tg-masonrygrid womenlaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-01.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid womenlaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-02.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid lethallaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-03.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid criminallaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-04.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid childlaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-05.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid criminallaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-06.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid childlaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-07.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid vatinarylaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-08.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid suicidelaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-09.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid vatinarylaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-10.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid suicidelaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-11.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
									<div class="tg-masonrygrid lethallaw">
										<div class="tg-gallery">
											<figure class="tg-themeimgborder">
												<a href="#"><img src="images/gallery/img-12.jpg" alt="image description"></a>
											</figure>
											<div class="tg-galleryhover">
												<div class="tg-leftarea">
													<time datetime="2017-12-12">June 27, 2013</time>
													<div class="tg-title">
														<h2>How To Stay Alive In Market</h2>
													</div>
												</div>
												<a class="tg-btnexpand" href="images/gallery/img-01.jpg" data-rel="prettyPhoto[gallery]"><i class="icon-frame-expand"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>-->
            
			<!--************************************
					Gallery End						
			*************************************-->
            
			<!--************************************
					Sponser End						
			*************************************-->
			<section class="tg-sectionspace tg-haslayout tg-bgparallax tg-bgsponser"><center>
				<div class="container">
					<div class="row">
						<div class="col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-12 col-md-offset-2 col-md-8 col-lg-offset-2">
							<div class="tg-sectionhead tg-colorwhite">
								<div class="tg-sectionheading">
									<!--<h2>Brands Behind Us</h2>-->
									<h3>Technical Partners</h3>
								</div>
								<div class="tg-description">
							<!--		<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt utnaecte laboret dolore magna aliqua enim adiatai minim veniam quista nostrud exercitation ullamco laboris nisi ut aliquip exeation.</p>-->
								</div>
							</div>
						</div>
						<ul class="tg-sponsers">
							<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
									<img src="images/sponser/sap.png" alt="image description">									</a>								</figure>
							</li>
                            
                            <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
									<img src="images/sponser/ec-council.png" alt="image description">									</a>								</figure>
							</li>
                            
                            <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
									<img src="images/sponser/ncsss.png" alt="image description">									</a>								</figure>
							</li>
                            
                            <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
									<img src="images/sponser/bosch.png" alt="image description">									</a>								</figure>
							</li>
						</ul>
					<!--	<a class="tg-btn" href="javascript:void(0);">Become A Sponser</a>-->
					</div>
				</div></center>
			</section>
			<!--************************************
					Sponser End						
			*************************************-->
            
            
            
   	<!--************************************
					Sponser End						
			*************************************-->
			<section class="tg-sectionspace tg-haslayout tg-bgparallax tg-bgsponser">
				<div class="container">
					<div class="row">
						<div class="col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-12 col-md-offset-2 col-md-8 col-lg-offset-2 col-lg-8">
							<div class="tg-sectionhead tg-colorwhite">
								<div class="tg-sectionheading">
									<!--<h2>Brands Behind Us</h2>-->
									<h3>Our Sponsors</h3>
								</div>
								<div class="tg-description">
							<!--		<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt utnaecte laboret dolore magna aliqua enim adiatai minim veniam quista nostrud exercitation ullamco laboris nisi ut aliquip exeation.</p>-->
								</div>
							</div>
						</div>
						<ul class="tg-sponsers">
						<!--	<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/ec-council.png" alt="image description">
									</a>
								</figure>
							</li>-->
							<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/eusai.png" alt="image description">									</a>								</figure>
							</li>
							<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/cambridge.png" alt="image description">									</a>								</figure>
							</li>
							<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/huawei.png" alt="image description">									</a>								</figure>
							</li>
							<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/digiperform.png" alt="image description">									</a>								</figure>
							</li>
							<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/tally.png" alt="image description">									</a>								</figure>
							</li>
							<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/nse.png" alt="image description">									</a>								</figure>
							</li>
							<!--<li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/bosch.png" alt="image description">
									</a>
								</figure>
							</li>-->
                            <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/autodesk.png" alt="image description">									</a>								</figure>
							</li>
                           <!-- <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/sap.png" alt="image description">
									</a>
								</figure>
							</li>-->
                             <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/fortis.png" alt="image description">									</a>								</figure>
							</li>
                             <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/rana.png" alt="image description">									</a>								</figure>
							</li>
                               <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/legrand.png" alt="image description">									</a>								</figure>
							</li>
                              <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/iiid.png" alt="image description">									</a>								</figure>
							</li>
                          <!--  <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/ncsss.png" alt="image description">
									</a>
								</figure>
							</li>-->
                            <li>
								<figure class="tg-sponder">
									<a href="javascript:void(0);">
										<img src="images/sponser/cii.png" alt="image description">									</a>								</figure>
							</li>
						</ul><BR>
						<a class="tg-btn" href="pdf/imarc-sponsorship.pdf" style="color:#CC0000"><B>BECOME A SPONSOR</B></a>
					</div>
				</div>
			</section>
			<!--************************************
					Sponser End						
			*************************************-->
            
            
            
            
            
			<!--************************************
					Price Plan Start				
			*************************************-->
			<section class="tg-sectionspace tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-12 col-md-offset-2 col-md-8 col-lg-offset-2 col-lg-8">
							<div class="tg-sectionhead">
								<div class="tg-sectionheading">
									<!--<h2>Best Price Guarantee</h2>-->
									<h3 style="color:#224484">IMARC-2019: REGISTRATION DETAILS</h3>
								</div>
								<div class="tg-description">
									<!--<p></p>-->
								</div>
							</div>
						</div>
                        
                        
                        
              <div style="overflow-x: auto; width:100%">  
              <table width="644" class="registration-table">
<tbody>
<tr>
<td rowspan="2" width="125">
<p><strong>Authors</strong></p></td>
<td colspan="2" width="186">
<p><strong>Early Bird<br> Before 15th July </strong></p></td>
<td colspan="2" width="184">
<p><strong>Standard Time <br>16th July-15th August,<br> 2019</strong></p></td>
<td colspan="2" width="149">
<p><strong>Late Registration <br>After 15th August</strong></p></td>
</tr>
<tr>
<td width="105">
<p><strong>International</strong></p></td>
<td width="81">
<p><strong>National</strong></p></td>
<td width="105">
<p><strong>International</strong></p></td>
<td width="79">
<p><strong>National</strong></p></td>
<td width="75">
<p><strong>International</strong></p></td>
<td width="74">
<p><strong>National</strong></p></td>
</tr>
<tr>
<td width="125">
<p>Students</p></td>
<td width="105">
<p>50$</p></td>
<td width="81">
<p>3000</p></td>
<td width="105">
<p>55$</p></td>
<td width="79">
<p>3500</p></td>
<td width="75">
<p>60$</p></td>
<td width="74">
<p>4000</p></td>
</tr>
<tr>
<td width="125">
<p>Faculty</p></td>
<td width="105">
<p>120$</p></td>
<td width="81">
<p>3500</p></td>
<td width="105">
<p>125$</p></td>
<td width="79">
<p>4000</p></td>
<td width="75">
<p>150$</p></td>
<td width="74">
<p>4500</p></td>
</tr>
<tr>
<td width="125">
<p>Academicians/ Industry</p></td>
<td width="105">
<p>120$</p></td>
<td width="81">
<p>4500</p></td>
<td width="105">
<p>125$</p></td>
<td width="79">
<p>5000</p></td>
<td width="75">
<p>150$</p></td>
<td width="74">
<p>5500</p></td>
</tr>
</tbody>
</table></div>

<!--<p><b> REFUND / CANCELLATION POLICY</b></p><br>
<p>Where the registrant is unable to attend  then the following refund arrangements apply:<br>
1.	Cancellations more than 60 days before the event - 50% of the registration fees will be refunded<br>
2.	Cancellations less than 60 but more than 45 days before the event- 25% of the registration fees will be refunded.<br>
3.	Cancellations less than 45 days before the event- not eligible for a refund. </p>
-->
<p><b>REGISTRATION PACKAGE </b></p>
<p><ul>
<li>Admission to all Sessions</li>
<li>Speakers slot for presentation</li>
<li>Conference Bag</li>
<li>Morning and evening coffee/tea & Lunch (Day One)</li>
<li>Free Conference tour with lunch (Day Two)</li>
<li>Souvenir – cum- Book of Extended Abstracts   </li>
<li>Certificate of presentation</li>
<li>Printed Conference Program</li>
<li>Publication of the paper </li>

</ul></p>

<!--<p><b>COST EXCLUDES </b></p>
<p><ul>
<li>Return Air Ticket and related expenditure</li>
<li>Expenses of personal Nature ( e.g., mineral water, Soft Drinks, Juice, Cocktail, Laundry, Tips, etc.) </li>
<li>Any kind of transportation, sightseeing, entry fees for visiting museum, any other service onrher than mentioned in the Registration Package</li>
<li>Bank Credit Card Charges for online payment made by card</li>
<li>All other meals and services other than mentioned in the Registration Package</li>
<li>Any Taxe(s) levied by Government, e.g., GST, VAT , etc. </li>

</ul></p>-->

<p><b>SOUVENIR –CUM- BOOK OF EXTENDED ABSTRACTS </b></p>
<p><ul>
<li>A Souvenir – cum- Book of Extended Abstracts  in commemoration of the IMARC-2019 will be brought and distributed to all the Registered of  Delegates of the  Conference. </li>
<li>The details of tariffs for advertisement are as follows:</li>

<div class="divTable">
<div class="divTableBody">
<div class="divTableRow">
<div class="divTableCell">Cover (back coloured)&nbsp;&nbsp;&nbsp;</div>
<div class="divTableCell">INR : 1,00,000</div>
</div>
<div class="divTableRow">
<div class="divTableCell">Cover-II (inside, coloured)&nbsp;&nbsp;</div>
<div class="divTableCell">INR : 90,000</div>
</div>
<div class="divTableRow">
<div class="divTableCell">Cover-III(inside, coloured)&nbsp;&nbsp;</div>
<div class="divTableCell">INR : 80,000</div>
</div>
<div class="divTableRow">
<div class="divTableCell">Full Paid (Coloured)</div>
<div class="divTableCell">INR: 50,000</div>
</div>
<div class="divTableRow">
<div class="divTableCell">Half Page (Coloured)</div>
<div class="divTableCell">INR: 30,000</div>
</div>
<div class="divTableRow">
<div class="divTableCell">Full Page ( B/W)</div>
<div class="divTableCell">INR: 40,000</div>
</div>
<div class="divTableRow">
<div class="divTableCell">Half Page (B/W)</div>
<div class="divTableCell">INR: 20,000</div>
</div>
</div>
</div>


</ul></p>
                        
<!--						<div class="tg-packages">
							<div class="tg-package tg-basic">
								<div class="tg-packagehead">
									<i class="icon-home"></i>
									<h2>Basic Plan</h2>
								</div>
								<span class="tg-price">
									<sup>$</sup>
									<h3>14</h3>
									<sub>/ Day</sub>
								</span>
								<p class="tg-attendmember">01 member can attend</p>
								<ul class="tg-packageinfo">
									<li>
										<span>01</span>
										<p>Conference Seats Available</p>
									</li>
									<li>
										<span>01</span>
										<p>Workshops Available</p>
									</li>
									<li>
										<span>01</span>
										<p>Breaks Available</p>
									</li>
								</ul>
								<a class="tg-btn" href="#">Select Plan</a>
							</div>
							<div class="tg-package tg-standard">
								<div class="tg-packagehead">
									<span class="tg-badge">best</span>
									<i class="icon-briefcase"></i>
									<h2>Standard Plan</h2>
								</div>
								<span class="tg-price">
									<sup>$</sup>
									<h3>29</h3>
									<sub>/ Day</sub>
								</span>
								<p class="tg-attendmember">02 member can attend</p>
								<ul class="tg-packageinfo">
									<li>
										<span>02</span>
										<p>Conference Seats Available</p>
									</li>
									<li>
										<span>01</span>
										<p>Workshops Available</p>
									</li>
									<li>
										<span>02</span>
										<p>Breaks Available</p>
									</li>
								</ul>
								<a class="tg-btn" href="#">Select Plan</a>
							</div>
							<div class="tg-package tg-premium">
								<div class="tg-packagehead">
									<i class="icon-apartment"></i>
									<h2>Premium Plan</h2>
								</div>
								<span class="tg-price">
									<sup>$</sup>
									<h3>80</h3>
									<sub>/ Day</sub>
								</span>
								<p class="tg-attendmember">03 member can attend</p>
								<ul class="tg-packageinfo">
									<li>
										<span>03</span>
										<p>Conference Seats Available</p>
									</li>
									<li>
										<span>01</span>
										<p>Workshops Available</p>
									</li>
									<li>
										<span>01</span>
										<p>Breaks Available</p>
									</li>
								</ul>
								<a class="tg-btn" href="#">Select Plan</a>
							</div>-->
						</div>
					</div>
				</div>
			</section>
			<!--************************************
					Price Plan End					
			*************************************-->
			<!--************************************
					Join Us Start					
			*************************************-->
			<section class="tg-haslayout tg-bgparallax tg-bgjoinus">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<div class="tg-joinusnow">
								<figure class="tg-signupimg">
									<img src="images/img-03.jpg" alt="image description">
									<figcaption>
										<div class="tg-signupcontent"><br><br>
											<h3><br>Hurry, Before Its Too Late</h3>
											<!--<h3>Seats Left</h3>-->
										</div>
									</figcaption>
								</figure>
<!--								<form class="tg-formtheme tg-formjoinus">
									<fieldset>
										<div class="form-group">
											<input type="text" name="first name" class="form-control" placeholder="Full Name*">
										</div>
										<div class="form-group">
											<input type="email" name="email" class="form-control" placeholder="Email">
										</div>
										<div class="form-group">
											<input type="text" name="phone" class="form-control" placeholder="Phone*">
										</div>
										<div class="form-group">
											<span class="tg-select">
												<select>
													<option>Select Price Plan*</option>
													<option>Daily</option>
													<option>Monthly</option>
													<option>Yearly</option>
													<option>Lifetime</option>
												</select>
											</span>
										</div>
										<div class="form-group">
											<textarea placeholder="Addtional Notes"></textarea>
										</div>
										<div class="form-group">
											<button class="tg-btn" type="submit">Register</button>
										</div>
									</fieldset>
								</form>-->
							</div>
						</div>
						<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
							<div class="tg-joinusoffer">
								<h3>Be an Early Bird!</h3>
								<h4>Early Bird Expire on: July 15, 2019</h4>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--************************************
					Join Us Start					
			*************************************-->
			<!--************************************
					Locations Start					
			*************************************-->
			<section class="tg-sectionspace tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="tg-shortcode tg-venueshortcode">
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<div class="tg-shortcodetext">
									<div class="tg-sectionhead tg-textalignleft">
										<div class="tg-sectionheading">
											<!--<h2>Locations Where You Can Stay</h2>-->
											<h3 style="color:#224484">Cultural Tour</h3>
										</div>
										<div class="tg-description">
											<p style="font-size:14px">Options for Cultural Tour will be open on payment basis after the Conference. The Cultural Tour will be organized for the Registered Delegates as per following details:<br>
<ul><li style="font-size:14px"><b>Date:</b> September 8, 2019- Explore Punjab</li>
<li style="font-size:14px"><b>Starting time:</b> 8.30 a.m.</li>
<li style="font-size:14px"><b>Meeting point:</b> Front Office Lobby of CT University, Ludhiana</li>
<li style="font-size:14px"><b>Time duration:</b> 08-10 hours</li></ul>
</p>
										</div>
									</div>
									<div class="tg-btnarea">
										<!--<a class="tg-btn" href="#">Read More</a>-->									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/tour/golden-temple.jpg" alt="">									</figure>
									<div class="tg-posttitle">
										<h4><a href="">Golden Temple</a></h4>
										<span>Amritsar</span>									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/tour/durgiana-temple.jpg" alt="">									</figure>
									<div class="tg-posttitle">
										<h4><a href="">Durgiana Temple</a></h4>
										<span>Amritsar</span>									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/tour/museum-rural-life-punjab.jpg" alt="">									</figure>
									<div class="tg-posttitle">
										<h4><a href="">Museum of Rural Life of Punjab</a></h4>
										<span>P.A.U. Ludhiana</a></span>									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/tour/devi-talab-mandir.jpg" alt="">									</figure>
									<div class="tg-posttitle">
										<h4><a href="">Devi Talab Temple</a></h4>
										<span>Jalandhar</span>									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/tour/martyrs-museum-kartarpur.jpg" alt="">									</figure>
									<div class="tg-posttitle">
										<h4><a href="">Museum of Martyrs </a></h4>
										<span>Kartarpur</span>									</div>
								</div>
							</div>
							<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
								<div class="tg-themepost tg-venue">
									<figure>
										<img src="images/tour/wagah-border.jpg" alt="">									</figure>
									<div class="tg-posttitle">
										<h4><a href="">Attari-Wagah International Border</a></h4>
										<span>Amritsar</span>									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!--************************************
					Locations End				
			*************************************-->
            
			<!--************************************
					FAQs Start						
			*************************************-->
            
			<section class="tg-haslayout tg-bgparallax tg-bgfaqs">
				<div class="container">
					<div class="row">
                    
                    
						<div class="tg-askquestions">
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                            
								<div class="tg-askquestionform tg-colorwhite">
									<div class="tg-sectionhead tg-textalignleft">
										<div class="tg-sectionheading">											
                                            <h3>Committee</h3><br>
											
                                            
                                            	<div id="tg-themescroll" class="tg-themeaccordian">
										<div id="tg-accordion" class="tg-accordion" role="tablist" aria-multiselectable="true">
											<div class="tg-panel">
												<h4 style="color:#224484"><span></span>Patron in Chief</h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p style="color:#000000">- S. Charanjit Singh Channi</p>
                                                        <p style="color:#000000">- Mr. Manbir Singh</p>
                                                        <p style="color:#000000">- Mr. Harpreet Singh</p>
													</div>
												</div>
											</div>
									
																					
										
											<div class="tg-panel">
												<h4 style="color:#224484"><span></span>Patron</h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p style="color:#000000">- Dr. Harsh Sadawarti, Vice Chancellor, CT University, Ludhiana</p>
                                                    </div>
												</div>
											</div>
                                            
                                            
                                            <div class="tg-panel">
												<h4 style="color:#224484"><span></span>Co-Patrons</h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p style="color:#000000">- Dr J.S Dhiman </p>
                                                        <p style="color:#000000">- Dr. G.S Kalra</p>
                                                        <p style="color:#000000">- Dr. Jasdeep Kaur Dhami</p>
                                                        <p style="color:#000000">- Dr. Yogesh Chabra </p>
                                                </div>
												</div>
											</div>
                                            
                                            
                                            	<div class="tg-panel">
												<h4 style="color:#224484"><span></span>Organizing Committee</h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p style="color:#000000">- Dr. G.S Bakshi</p>
                                                       <p style="color:#000000"> - Dr. Anupam Deep Sharma</p>

<p style="color:#000000">- Mr. Sukhminder Grewal</p>
<p style="color:#000000">- Dr. Saurabh Sharma</p>
<p style="color:#000000">- Dr. Pravin</p>
<p style="color:#000000">- Dr. Yogeeta</p>
<p style="color:#000000">- Mr. Munish Kaushal</p>
<p style="color:#000000">- Dr. Kamaljeet Kaur</p>
<p style="color:#000000">- Dr. Amrinder</p>
<p style="color:#000000">- Dr. Amit</p>
<p style="color:#000000">- Ms. Geetanjali</p>
                                                     </div>
												</div>
											</div>
                                            
                                            <div class="tg-panel">
												<h4 style="color:#224484"><span></span>Technical Committee</h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p style="color:#000000">- Dr. Sachit Vardhan</p>
                                                        <p style="color:#000000">- Dr. Kamal Malik</p>
<p style="color:#000000">- Dr. Sita Saini</p>
<p style="color:#000000">- Dr. Harpreet Singh</p>
<p style="color:#000000">- Mr. Anurag Sharma</p>
<p style="color:#000000">- Dr. Rajiv     </p>

                                                     </div>
												</div>
											</div>
                                            
                                               <div class="tg-panel">
												<h4 style="color:#224484"><span></span>Event &amp; Sponsorship Committee</h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p style="color:#000000">- Dr. Sachin Sharma</p>
<p style="color:#000000">- Dr. Kavita</p>
<p style="color:#000000">- Dr. Kiran Sood</p>
<p style="color:#000000">- Mr. Jaswinder Sekhon</p>
<p style="color:#000000">- Mr.Gagandeep Singh</p>
                                                     </div>
												</div>
											</div>
                                            
                                               <div class="tg-panel">
												<h4 style="color:#224484"><span></span>Workshop Committee</h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p style="color:#000000">- Dr. Harmeet</p>
														<p style="color:#000000">- Mr. Jaspreet Singh</p>
														<p style="color:#000000">- Mr. Febin Prakash</p>
														<p style="color:#000000">- Dr. Anshul Kalia</p>
                                                     </div>
												</div>
											</div>
                                            
                                              <div class="tg-panel">
												<h4 style="color:#224484"><span></span>Publication &amp; Media Committee </h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p style="color:#000000">- Mr. Kanwalpreet Singh</p>
<p style="color:#000000">- Ms. Gursimar Midha</p>
<p style="color:#000000">- Mr. Inderjeet Singh</p>
<p style="color:#000000">- Ms. Jaspreet Kaur</p>
<p style="color:#000000">- Ms. Nikita Dhawan</p>
<p style="color:#000000">- Ms. Shilpi </p>
<p style="color:#000000">- Ms. Mandeep Kaur</p>

                                                     </div>
												</div>
											</div>
										</div>
									</div>
										</div>
									</div>
								</div>
							</div>
                            
							<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
								<div class="tg-commonquestions">
									<figure class="tg-signupimg">
										<img src="images/img-03.jpg" alt="image description">
										<figcaption>
											<div class="tg-signupcontent">
												<h2></h2>
												<h3>ADVISORY BOARD</h3>
											</div>
										</figcaption>
									</figure>
									<!--<form class="tg-formtheme tg-fomrsearch">
										<fieldset>
											<div class="form-group tg-inputicon">
												<button type="submit"><i class="fa fa-search"></i></button>
												<input type="search" name="search" class="form-control" placeholder="Search Here">
											</div>
										</fieldset>
									</form>-->
									<div id="tg-themescroll" class="tg-themeaccordian tg-themescrollbar">
										<div id="tg-accordion" class="tg-accordion" role="tablist" aria-multiselectable="true">
											<div class="tg-panel">
												<h4><span></span><B>INTERNATIONAL ADVISORY BOARD</B></h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p><ul><li>
                                                        Prof (Dr) Shiv O Prasher, Head of Department of Bioresource Engineering, James Mc Gill University, Canada</li>
                                                        <li> Dr. Sarbjeet Singh, Lulea University of Technology, Sweden</li>
                                                        <li> Jaskaran Dhiman, Research Scientist and Teaching Associate / Quebec of the IC-IMPACTS SEC, Mc Gill University, Montreal, Canada</li>
                                                        <li>Dr. Marisha Mcauliffe, Academic Director, Barclays College, Melbourne, Australia & Darlo Higher Education, India (Australia)</li>
                                                        <li>Witold Mat, Client Experience Optimisation / International Partnership Development, Fort Hays State University, United Kingdom</li>
                                                        <li> Cristi Spulbar, Faculty of Economics & Business Administration, University of Craiova, Dolj County, Romania </li>
                                                      <li>Dr. Chithirai Pon Selvan, Head of School of Science and Engineering, Curtin University, Dubai</li>
                                            <li>J. Luis Guasch, Professor of Economics,	University of California, Washington, District of Columbia</li>
                                            <li>Valentina Emilia Balas, Professor, Ph.D, Aurel Vlaicu University of Arad, Arad, Romania</li>
                                            <li>Richard Bush, Dean, College of Information Technology, Baker College, Greater Detroit Area, USA</li>
                                            <li>Fernando Suarez Gonzalez, Senior Business Consultant, Jose Maria Vargas University, Funchal, Maderia, Portugal</li>
                                            <li> Prof. Dr. Faridah Hj Hassan Halal, Marketing & Strategic Management. INQKA & AAGBS Universiti Teknologi MARA, Selangor, Malaysia</li>
                                            <li>Fabrice NKURUNZIZA, Lecturer & Head of Applied Economics Department, INES-Ruhengeri, Rwanda</li>
                                            <li> Wolfgang Amann, Professor, Goethe Business School - Goethe University, Frankfurt, HEC Paris </li>
                                            <li> Dr. Abbas Fadhil Aljuboori, Vice President for Administrative Affairs, University of Information Technology and Communications, Iraq</li>
                                            <li>Dr. David Asirvatham, Executive Dean, Faculty of Built Environment, Engineering, Technology and Design, Taylor’s University, MALAYSIA</li>
                                            <li>Dr. Edel Garcia, Ph.D, Multidisciplinary Scientist, Founder, Minerazzi.com</li>
                                            <li> Dr. Chockalingem, Programme Director - Electrical and Electronic Engineering, Taylor's University, Malaysia</li>
                                            <li> Abdul Salam Mohammad Niyaz, Assistant Professor, Gyeongju University, Republic of Korea, Sri Lanka</li>
                                            <li> Wael Al Buzz, Associate Professor, Taif University, Jordan</li>
                                            <li> Marcin Paprzycki, Associate Professor, IBS PAN Warsaw, Masovian District, Poland</li>
                                            <li> Shaymaa Tahhan, Lecturer Doctorate, College of Engineering, AlNahrain University, Iraq</li>
                                            <li> Dr. Ramona Birau, Lecturer Ph.D., Faculty of Economics and Business Administration, Constantin Brâncuși University of Targu Jiu	Dolj County, Romania</li>
                                                        </ul>
                                                        </p>
													</div>
												</div>
											</div>
									
											
                                            <div class="tg-panel">
												<h4><span></span><B>REVIEWER BOARD</B></h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p><ul>
<li>Prof (Dr) Shiv O Prasher, Head of Department of Bioresource Engineering, James Mc Gill, Canada </li>
<li>Cristi Spulbar, Faculty of Economics & Business Administration, University of Craiova, Dolj County, Romania </li>
<li>Dr. Chithirai Pon Selvan, Head of School of Science and Engineering, Curtin University, Dubai</li>
<li>J. Luis Guasch, Professor of Economics, University of California, Washington, District of Columbia</li>
<li>Valentina Emilia Balas, Professor, Ph.D., Aurel Vlaicu University of Arad, Arad Country, Romania</li>
<li>Richard Bush, Dean, College of Information Technology, Baker College, Greater Detroit Area, USA</li>
<li>Prof. Dr Faridah Hj Hassan Halal, Marketing & Strategic Management, INQKA & AAGBS Universiti Teknologi MARA Selangor, Malaysia</li>
<li>Fabrice NKURUNZIZA, Lecturer & Head of Applied Economics Department, INES-Ruhengeri, Rawanda</li>
<li>Wolfgang Amann, Professor, Goethe Business School - Goethe University, Frankfurt, HEC Paris </li>
<li>Dr. Abbas Fadhil Aljuboori, Vice President for Administrative Affairs, University of Information Technology and Communications, Iraq</li>
<li>Dr David Asirvatham, Executive Dean, Faculty of Built Environment, Engineering, Technology and Design, Taylor’s University, MALAYSIA</li>
<li>Dr. Edel Garcia, Ph.D., Multidisciplinary scientist		</li>
<li>Abdul Salam Mohammad Niyaz, Assistant Professor, Gyeongju University, Republic of Korea, Sri Lanka</li>
<li>Wael Al Buzz, Associate Professor, Taif University, Jordan</li>
<li>Marcin Paprzycki, Associate Professor, IBS PAN Warsaw, Masovian District, Poland</li>
<li>Shaymaa Tahhan, Lecturer Doctorate, College of Engineering, alNahrain University, Iraq</li>
<li>Dr. Ramona Birau, Lecturer Ph.D., Faculty of Economics and Business Administration, Constantin Brâncuși University of Targu Jiu, Dolj County, Romania</li>
<li>Jafar A. Alzubi, Associate Professor, Al-Balqa Applied University Salt - 19117, Jordan Jointly with Wake Forest University North Carolina USA</li>
<li>Prof. K. S. JAGANNATHA RAO, Director, Institute for Scientific Research and Technology Services (INDICASAT-AIP)	</li>
<li>Dr. Rajeev K Puri, Professor, Departmnet of Physics, Punjab University, Chandigarh, India</li>
<li>Pugazhenthi, Consulting Faculty in CII Institute of Logistics, Chennai, India</li>
<li>Dr. Gurdeep Singh Batra, Professor of Management, Punjabi university, Patiala, Punjab, India</li>
<li>Raj Kapoor, Co-Founder, India Stem Alliance, India</li>
<li>Dr. Anil Verma, Professor of Computer Science, Thapar University, Patiala, Punjab, India	</li>
<li>Dr. N.Kala Baskar, Director-in-Charge, Centre for Cyber Forensics and Information Security
, University of Madras, Chennai, India</li>
<li>Ar. Manmohan Khanna, Principal Architect, KMA Architecture</li>


                                                        </ul></p>
													</div>
												</div>
											</div>
                                            										
										
											<div class="tg-panel">
												<h4><span></span><B>ACADEMIC ADVISORY BOARD</B></h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p><ul>
<li>Dr. Rajeev K Puri, Professor Department of Physics, Punjab University, Chandigarh, India</li>
<li>Mr. Pugazhenthi, Consulting Faculty, CII Institute of Logistics, Chennai, India</li>
<li>Dr. G.S Batra, Professor of Management, Punjabi university, Patiala, Punjab, India</li>
<li>Mr. Raj Kapoor, Co-Founder, India Stem Alliance, India</li>
<li>Dr. Anil Verma, Professor of Computer Science, Thapar University, Patiala, Punjab, India</li>
<li>Dr. N.Kala Baskar, Director-in-Charge, Centre for Cyber Forensics and Information Security, 
University of Madras, Chennai, India</li>
<li>Ar. Manmohan Khanna, Principal Architect, KMA Architecture	</li>
<li>Dr. Barjinder Singh Rana, Owner, Rana Hospital, Ludhiana, Punjab, India</li>

                                                        </ul></p>
													</div>
												</div>
											</div>
                                            
                                            
                                            <div class="tg-panel">
												<h4><span></span><B>CORPORATE ADVISORY BOARD</B></h4>
												<div class="tg-panelcontent">
													<div class="tg-description">
														<p><ul>
<li> Mr. Sohinder Singh, President, Nahar Spinning Mills Ltd., Ludhiana, Punjab</li>
<li>Mr. Munish Jindal, Founder & CEO, Hover Robotix	Ludhiana, Punjab</li>
<li>Ms. Nafisa Yeasmin, Director and CEO, Kiandas Business Academy Pvt. Ltd., Kolkata, India</li>
<li>Dr. Vivan Singh Gill, Zonal Director, Fortis Hospital, Jaipur</li>
<li>Mr. Pavit Chhabra, Assistant Vice President, Citi Corporation, Pune</li>
<li>Mrs. Sadhana Yogesh Ghalsasi, Certified SAP Trainer, SAP certified Solution Architect</li>



                                                        </ul></p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>                                    <br><br><br>
			</section>
			<!--************************************
					FAQs End						
			*************************************-->
			<!--************************************
					Latest Articles Start			
			*************************************-->
            
<!--			<section class="tg-sectionspace tg-haslayout">
				<div class="container">
					<div class="row">
						<div class="col-xs-offset-0 col-xs-12 col-sm-offset-0 col-sm-12 col-md-offset-2 col-md-8 col-lg-offset-2 col-lg-8">
							<div class="tg-sectionhead">
								<div class="tg-sectionheading">
									<h2>Always Stay Updated</h2>
									<h3>Latest Tips &amp; Articles</h3>
								</div>
								<div class="tg-description">
									<p>Consectetur adipisicing elit sed do eiusmod tempor incididunt utnaecte laboret dolore magna aliqua enim adiatai minim veniam quista nostrud exercitation ullamco laboris nisi ut aliquip exeation.</p>
								</div>
							</div>
						</div>
						<div class="tg-latestarticles">
							<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<article class="tg-post tg-themepost">
									<figure>
										<span class="tg-timetag">June 27, 2016</span>
										<img src="images/articles/img-01.jpg" alt="image description">
									</figure>
									<div class="tg-postcontent">
										<div class="tg-posthead">
											<ul class="tg-tags">
												<li><a href="#">Lifestyle, </a></li>
												<li><a href="#">Business</a></li>
											</ul>
											<ul class="tg-matadata tg-postmatadata">
												<li>
													<i class="icon-bubble"></i>
													<span><a href="#">3205</a></span>
												</li>
											</ul>
										</div>
										<div class="tg-posttitle">
											<h3><a href="">Penny Smart, Dollar Foolish</a></h3>
										</div>
										<div class="tg-description">
											<p>Consectetur adipisicing elit sed eiusmod tempor inciunt labore dolore magna aliqua enim.</p>
										</div>
									</div>
								</article>
							</div>
							<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<article class="tg-post tg-themepost">
									<figure>
										<span class="tg-timetag">June 27, 2016</span>
										<img src="images/articles/img-02.jpg" alt="image description">
									</figure>
									<div class="tg-postcontent">
										<div class="tg-posthead">
											<ul class="tg-tags">
												<li><a href="#">Law and Finance</a></li>
											</ul>
											<ul class="tg-matadata tg-postmatadata">
												<li>
													<i class="icon-bubble"></i>
													<span><a href="#">3205</a></span>
												</li>
											</ul>
										</div>
										<div class="tg-posttitle">
											<h3><a href="">All That Glitters Is Not Gold</a></h3>
										</div>
										<div class="tg-description">
											<p>Consectetur adipisicing elit sed eiusmod tempor inciunt labore dolore magna aliqua enim.</p>
										</div>
									</div>
								</article>
							</div>
							<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<article class="tg-post tg-themepost">
									<figure>
										<span class="tg-timetag">June 27, 2016</span>
										<img src="images/articles/img-03.jpg" alt="image description">
									</figure>
									<div class="tg-postcontent">
										<div class="tg-posthead">
											<ul class="tg-tags">
												<li><a href="#">Lifestyle, </a></li>
												<li><a href="#">Business</a></li>
												<li><a href="#">Law and Fina...</a></li>
											</ul>
											<ul class="tg-matadata tg-postmatadata">
												<li>
													<i class="icon-bubble"></i>
													<span><a href="#">3205</a></span>
												</li>
											</ul>
										</div>
										<div class="tg-posttitle">
											<h3><a href="">Gonna Make You An Offer You Can�t Refuse</a></h3>
										</div>
										<div class="tg-description">
											<p>Consectetur adipisicing elit sed eiusmod tempor inciunt labore dolore magna aliqua enim.</p>
										</div>
									</div>
								</article>
							</div>
						</div>
					</div>
				</div>
			</section>-->
            
			<!--************************************
					Latest Articles End				
			*************************************-->
            
            
			<!--************************************
					Map Start						
			*************************************-->
			<section class="tg-haslayout">
				<div class="container-fluid">
					<div class="row">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6852.713886677494!2d75.555125!3d30.820663!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xe42e2905c6bf8817!2sCT+University!5e0!3m2!1sen!2sin!4v1549299205543" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
						<!--<div id="tg-locationmap" class="tg-locationmap tg-map"></div>-->
					</div>
				</div>
			</section>
			<!--************************************
					Map End							
			*************************************-->
		</main>
		<!--************************************
				Main End
		*************************************-->
		<!--************************************
				Footer Start
		*************************************-->
		<footer id="tg-footer" class="tg-footer tg-haslayout">
			 <?php include ("footer.php"); ?>
		</footer>
		<!--************************************
				Footer End
		*************************************-->
	</div>
	<!--************************************
			Wrapper End
	*************************************-->
	<script src="js/vendor/jquery-library.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="https://maps.google.com/maps/api/js?key=AIzaSyCR-KEWAVCn52mSdeVeTqZjtqbmVJyfSus&language=en"></script>
	<script src="js/customScrollbar.min.js"></script>
	<script src="js/packery.pkgd.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.hoverdir.js"></script>
	<script src="js/jquery.vide.min.js"></script>
	<script src="js/jquery.fullpage.js"></script>
	<!--<script src="js/color-switcher.js"></script>-->
	<script src="js/isotope.pkgd.js"></script>
	<script src="js/prettyPhoto.js"></script>
	<script src="js/countdown.js"></script>
	<script src="js/countTo.js"></script>
	<script src="js/appear.js"></script>
	<script src="js/gmap3.js"></script>
	<script src="js/main.js"></script>
</body>
</html>