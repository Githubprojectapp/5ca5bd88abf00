<div class="tg-sectionspace tg-haslayout tg-bgparallax tg-bgtwitter"><a name="contact"></a>
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-xs-offset-0 col-md-8 col-md-offset-2 col-lg-8 col-lg-offset-2">
							<div class="tg-twitterpost">
								<!--<i class="fa fa-facebook"></i>
								<span class="tg-followus">Follow <a href="https://www.facebook.com/CTUniversityludhiana">@CTUniversityludhiana</a> &amp; Stay Updated</span>-->
								<div class="tg-description">
									<p style="color:#FFFFFF"><span>For further details, please contact:</span><br><br>
                                   Dr. Sachit Vardhan,<br> Deputy Director Research, <br>CT University, Ludhiana<br>Tel: +91-90566-60555, <br> Email:&#115;&#097;&#099;&#104;&#105;&#116;&#046;&#049;&#055;&#048;&#052;&#056;&#064;&#099;&#116;&#117;&#110;&#105;&#118;&#101;&#114;&#115;&#105;&#116;&#121;&#046;&#105;&#110;&#032;                                     </p><br>
                                     <p style="color:#FFFFFF">
                                Dr. Kamal Malik,<br>  Associate Professor, <br>CT University, Ludhiana<br>Tel: +91- 70150-48467, <br> Email:
&#107;&#097;&#109;&#097;&#108;&#049;&#055;&#050;&#048;&#051;&#064;&#099;&#116;&#117;&#110;&#105;&#118;&#101;&#114;&#115;&#105;&#116;&#121;&#046;&#105;&#110;
</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="tg-foorterbar">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<p class="tg-copyrights"><a href="https://www.ctuniversity.in">Leading Industry Driven University, Punjab, India</a></p>
                           
							<ul class="tg-socialicons">
								<li class="tg-facebook"><a href="https://www.facebook.com/CTUniversityludhiana/"><i class="fa fa-facebook"></i></a></li>
								<li class="tg-twitter"><a href="https://twitter.com/CT_University"><i class="fa fa-twitter"></i></a></li>
								<li class="tg-linkedin"><a href="https://www.youtube.com/channel/UCOD3pxKIGVtpKdqKXsYvi5Q"><i class="fa fa-youtube"></i></a></li>
								<li class="tg-googleplus"><a href="https://www.instagram.com/ctuniversityofficial/"><i class="fa fa-instagram"></i></a></li>
							</ul>
							<strong class="tg-logo"><a href="https://www.ctuniversity.in" target="_blank"><img src="images/CT-LOGO-PNG-compressor.png" alt="CT UNIVERSITY LUDHIANA PUNJAB"></a></strong>						</div>
					</div>
				</div>
			</div>