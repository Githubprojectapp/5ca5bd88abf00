<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<strong class="tg-logo"><a href="index.php"><img src="images/logo2.png" alt="IMARC 2019 CT UNIVERSITY LUDHIANA"></a></strong>
						<div class="tg-navigationarea">
							<nav id="tg-nav" class="tg-nav">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#tg-navigation" aria-expanded="false">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
								</div>
								<div id="tg-navigation" class="collapse navbar-collapse tg-navigation">
									<ul>
										<!--<li class="menu-item-has-children current-menu-item">-->
                                        <li class="current-menu-item">
											<a href="index.php#imarc">Call for Paper</a>
											<ul class="sub-menu">
												<li><a href="schedule.php">Conference Schedule</a></li>
												<li><a href="index.php#deadlines">Important Deadlines</a></li>
												<li><a href="index.php#speakers">Speakers</a></li>
												
											</ul>
										</li>
										<!--<li class="menu-item-has-children">
											<a href="javascript:void(0);">Schedule</a>
											<ul class="sub-menu">
												<li><a href="schedule.html">Conference Schedule</a></li>
												<li><a href="index.html#deadlines">Important Deadlines</a></li>
											</ul>
										</li>-->
										<li class="">
                                     <!--   <li class="menu-item-has-children">-->
											<a href="pdf/imarc-guidelines.pdf">Guidelines</a>
											<!--<ul class="sub-menu">
												<li><a href="speakers.html">Speakers</a></li>
												<li><a href="speakerdetail.html">Speakers detail</a></li>
											</ul>-->
										</li>
										<li><a href="themes.php">Themes</a></li>
										<li><a href="venue.php">Venue</a></li>

								<!--		<li class="menu-item-has-children">
											<a href="javascript:void(0);">Pages</a>
											<ul class="sub-menu tg-darkmenu">
												<li><a href="aboutus.html">About Us</a></li>
												<li><a href="accomodation.html">Accomodations</a></li>
												<li><a href="contactus.html">Contact</a></li>
												<li><a href="sponsers.html">Sponsors</a></li>
												<li><a href="faqs.html">FAQs</a></li>
												<li><a href="gallery.html">Gallery</a></li>
												<li><a href="404error.html">404 error</a></li>
												<li><a href="comingsoon.html">Coming Soon</a></li>
												<li class="menu-item-has-children">
													<a href="javascript:void(0);">news</a>
													<ul class="sub-menu tg-darkmenu">
														<li><a href="newsgrid.html">News grid</a></li>
														<li><a href="newslist.html">news list</a></li>
														<li><a href="newsdetail.html">news detail</a></li>
													</ul>
												</li>
											</ul>
										</li>-->
                                        
                                        <li><a href="index.php#contact">Contact</a></li>
                                        <li><a href="http://ictesm.ctgroup.co.in" target="_blank">Previous Conference</a></li>
									</ul>
								</div>
                                
							</nav>
							<a class="tg-btn tg-btnbookseat" href="">Registration<!--<span> Seats Left</span>--></a>
						</div>
					</div>